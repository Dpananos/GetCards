# GetCards

Data scientist [Chris Albon](https://chrisalbon.com/) has been posting pictures of his machine learning flash cards [on Twitter](https://twitter.com/chrisalbon?lang=en).  Here is how to automatically download them using python.


### For OSX/Linux
In case you do not have the modules used in the notebook nor jupyter installed, simply type 
* `pip install -r module_list.txt`
 
into terminal. Then run the notebook from terminal with

* `jupyter notebook Get\ Flashcards.ipynb`
